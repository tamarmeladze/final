﻿namespace klasi
{
    public class CustomDate
    {
        public int Day { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }

        public CustomDate(int day, int month, int year)
        {
            Day = day;
            Month = month;
            Year = year;
        }

               public void AddDays(int days)
        {
            if (days < 31 && days >= 1)
            { Day += days; }
        }
        public void AddMonth(int months)
        {
            if (months <= 12 && months >= 1)
            {
                Month += months;
            }
        }
        public void Addyear(int years)
        {
            if (years >= 1)
            {
                Year += years;
            }
        }
        public static CustomDate operator -(CustomDate a, CustomDate b)
        {
            return new CustomDate(a.Day - b.Day, a.Month - b.Month, a.Year - b.Year);
        } 
        public override string ToString()
        {
            return $"{Year}-{Month}-{Day}";
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            CustomDate date1 = new(year: 2024, month: 12, day: 18);
            CustomDate date2 = new(year: 2025, month: 11, day: 3);
            Console.WriteLine(date2 - date1);
        }
    }
}

        
    



